const con = require("../models/ConnectToDatabase");

module.exports = async function(req, res) {

    res.status(200).json({message:"success"})

    try{
        const db = await con.getConnection();
        const userId = req.session.user.userId;
        const {tournamentName} = req.body
        const checkTeam = "SELECT * FROM Team_Info WHERE User_Id = ?"


        if (!userId) {
            return res.status(404).json({success: false, message: "No user found with this session"});
        }

        const [teams] = await db.execute(checkTeam, [req.session.user.userId]);

        if(teams.length >= 0) {
            console.error("entered if statement")
            await db.execute("UPDATE Team_Info SET Tournament_Id = ( SELECT id FROM Tournaments WHERE Tournament_Name = ? ) WHERE User_Id = ? AND Tournament_Id = 0", [tournamentName])
            res.status(200).json({message:"joined tournament successfully"})
        }


    } catch (error){
        console.error(error);
    }

    // try {
    //     const db = await con.getConnection();
    //     const { tournamentName } = req.body;
    //     const userId = req.session.user?.userId;
    //
    //     if (!userId) {
    //         return res.status(401).json({ message: "User not authenticated." });
    //     }
    //
    //     const [teams] = await db.execute(
    //         "SELECT id, Tournament_Id FROM Team_Info WHERE User_Id = ? AND Tournament_Id = 0",
    //         [userId]
    //     );
    //
    //     if (teams.length === 0 || undefined) {
    //         return res.status(400).json({ message: "You are not in a team or already in a tournament." });
    //     }
    //
    //     const teamId = teams[0].id;
    //
    //     const [tournaments] = await db.execute(
    //         "SELECT id, Current_Teams, Max_Teams FROM Tournaments WHERE Tournament_name = ? AND Current_Teams < Max_Teams LIMIT 1",
    //         [tournamentName]
    //     );
    //
    //     if (tournaments.length === 0 || undefined) {
    //         return res.status(404).json({ message: "Tournament not found or full." });
    //     }
    //
    //     const tournamentId = tournaments[0].id;
    //     const currentTeams = tournaments[0].Current_Teams;
    //
    //     await db.execute(
    //         "UPDATE Team_Info SET Tournament_Id = ? WHERE id = ?",
    //         [tournamentId, teamId]
    //     );
    //
    //     await db.execute(
    //         "UPDATE Tournaments SET Current_Teams = ? WHERE id = ?",
    //         [currentTeams + 1, tournamentId]
    //     );
    //
    //     res.status(200).json({ message: "Successfully joined the tournament!" });
    // } catch (error) {
    //     console.error("Error processing join request:", error.message);
    //     res.status(500).json({ message: "An internal server error occurred." });
    // }
};
